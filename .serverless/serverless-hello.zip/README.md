# Serverless Hello API

A simple AWS Lambda function triggered via API Gateway that returns a greeting.

## Endpoint
GET - https://9rl863hqfk.execute-api.eu-west-1.amazonaws.com/dev/hello
